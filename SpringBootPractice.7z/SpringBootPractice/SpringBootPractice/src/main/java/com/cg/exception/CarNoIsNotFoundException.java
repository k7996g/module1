package com.cg.exception;

public class CarNoIsNotFoundException extends Exception{
public CarNoIsNotFoundException(String message){
	super(message);
}
}
