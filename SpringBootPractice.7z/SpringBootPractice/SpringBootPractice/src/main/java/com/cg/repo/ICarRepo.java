package com.cg.repo;


import com.cg.beans.Car;
import com.cg.exception.CarNoIsNotFoundException;

public interface ICarRepo  {
	public Car addCar(Car car);
	Car getCar(int carNo) throws CarNoIsNotFoundException;
	Car deleteCar(int carNo) throws CarNoIsNotFoundException;
	Car updateCar(int carNo,int carPrice) throws CarNoIsNotFoundException;
	
}
