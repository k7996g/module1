package com.cg.exception;

public class ReceiverIdNotExistException extends IdNotExistException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
