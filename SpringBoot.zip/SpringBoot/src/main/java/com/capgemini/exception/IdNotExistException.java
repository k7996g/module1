package com.capgemini.exception;

public class IdNotExistException extends Exception {

}
