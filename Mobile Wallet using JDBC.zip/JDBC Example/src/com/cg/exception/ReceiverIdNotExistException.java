package com.cg.exception;

public class ReceiverIdNotExistException extends IdNotExistException {

}
