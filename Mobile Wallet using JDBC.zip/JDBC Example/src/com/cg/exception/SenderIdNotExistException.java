package com.cg.exception;

public class SenderIdNotExistException extends IdNotExistException {

}
