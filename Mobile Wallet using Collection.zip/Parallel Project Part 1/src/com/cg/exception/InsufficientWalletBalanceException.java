package com.cg.exception;

public class InsufficientWalletBalanceException extends Exception {

}
